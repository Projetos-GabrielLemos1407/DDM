package br.com.etecmcm.pulse_button

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
